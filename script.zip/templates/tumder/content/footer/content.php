<ul class="nav-footer">
	<li><a data-href="{{CONFIG_SITE_URL}}/home/english">@en@</a></li>
	<li><a data-href="{{CONFIG_SITE_URL}}/home/spanish">@es@</a></li>
	<li><a data-href="{{CONFIG_SITE_URL}}/home/french">@fr@</a></li>
	<li class="full">&copy; {{CONFIG_SITE_NAME}} 2017</li>
</ul>