	<script type="text/javascript">
        var __AdNum = {{CONFIG_AD_TIME}} + 1,
            __g_net = {{GET_GAME_ID}};
        window.setTimeout(function(){__upGame_rx8(__g_net)}, 15000);
        window.setTimeout(function(){__upGame_rx9()}, 200000);
        
        if ({{GAME_ADS_STATUS_COUNTER}}) {
        	__AdRemoveCount(); 
        	__adCountD();
        }
	</script>