<script type="text/javascript" src="{{CONFIG_THEME_PATH}}/js/admin/engine-admin.js"></script>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Trumbowyg/2.18.0/trumbowyg.min.js"></script>
<script>
    $('.editor-js').trumbowyg()
</script>