	<script type="text/javascript" src="{{CONFIG_SITE_URL}}/static/libs/js/chart.min.js"></script>
	<script type="text/javascript">
		var current_game_id = {{GET_GAME_ID}};

		$.ajax({
			url: Ajaxrequest() + '?t=admin&a=chart&p=played',
			data: 'gid=' + current_game_id,
            type: 'POST',
            success: function(data) {
            	var data = {
					labels: data['labels'],
					datasets: [{
						label: data['label'],
						fill: false,
						borderColor: "#00a3c6",
						borderCapStyle: 'butt',
						pointBorderColor: "#fff",
						pointBackgroundColor: "#00a3c6",
						pointBorderWidth: 2,
						pointRadius: 5,
						pointHitRadius: 5,
						data: data['datasets']
					}]
				};
                var myLineChart = new Chart(
                	document.getElementById("admintool_chart_game_analytics").getContext("2d"), 
                	{
    					type: 'line',
    					data: data
					}
				);
            }
		});
	</script>