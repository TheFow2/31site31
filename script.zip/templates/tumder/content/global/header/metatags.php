    <meta content="text/html; charset=UTF-8" http-equiv="content-type">
    <meta name="description" content="{{CONFIG_SITE_DESCRIPTION}}">
    <meta name="keywords" content="{{CONFIG_SITE_KEYWORDS}}">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">