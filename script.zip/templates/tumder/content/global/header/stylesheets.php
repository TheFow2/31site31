    <!--* Stylesheets *-->
    <link rel="stylesheet" type="text/css" href="{{CONFIG_THEME_PATH}}/css/98cb1q8d53p-1.css">
    <link rel="stylesheet" type="text/css" href="{{CONFIG_THEME_PATH}}/css/98cb1q8d53p-responsive.css">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,700&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese">
    <link rel="stylesheet" type="text/css" href="{{CONFIG_THEME_PATH}}/css/98cb1q8d53p-style.css">
    <link rel="stylesheet" type="text/css" href="{{CONFIG_THEME_PATH}}/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="{{CONFIG_THEME_PATH}}/css/libs/owl/owl.carousel.css">
    <link rel="stylesheet" type="text/css" href="{{CONFIG_THEME_PATH}}/css/libs/owl/owl.theme.css">
    <link rel="stylesheet" type="text/css" href="{{CONFIG_THEME_PATH}}/css/libs/sweetalert.css">
    <link rel="stylesheet" type="text/css" href="{{CONFIG_THEME_PATH}}/css/libs/toast.css">