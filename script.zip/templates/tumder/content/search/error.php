<div class="_a-c _e55">
	<div>
		<img src="{{CONFIG_THEME_PATH}}/image/icon-color/search.png">
	</div>
	<h3>@search_not_found@</h3>
</div>