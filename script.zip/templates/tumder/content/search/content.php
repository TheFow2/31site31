<div class="tumd-main main-box span100">
	{{SEARCH_CONTENT}}
</div>