<li class="card-item">
	<figure class="card-game">
		<a class="g-media" data-href="{{SEARCH_GAME_URL}}" href="{{SEARCH_GAME_URL}}">
			<img src="{{SEARCH_GAME_IMAGE}}" width="140px" height="96px">
			<span class="name ellipsis">{{SEARCH_GAME_NAME}}</span>
			<div class="meter mtr-2" value="{{SEARCH_GAME_RATING}}" title="{{SEARCH_GAME_RATING}} @of_5_stars@"></div>
			<figcaption class="caption">
				<div class="plays">
					<span class="fa fa-gamepad"></span>
					<span class="plays-num">{{SEARCH_GAME_PLAYS}}</span>
				</div>
			</figcaption>
		</a>
		<span class="cb-pro"></span>
	</figure>
</li>