<ul class="card">
	{{SEARCH_GAMES_LIST}}
</ul>