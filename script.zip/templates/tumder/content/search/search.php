<div class="_0e4">
	<div class="box-header">
		<i class="fa fa-search"></i> 
		@search_to@ 
		<strong>{{SEARCH_PARAMETER}}</strong>
	</div>
	<div class="_10e4">
		{{SEARCH_RESULT}}
	</div>
</div>