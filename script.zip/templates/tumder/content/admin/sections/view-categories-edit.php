<div class="general-box _0e4">
	<div class="header-box">
		<i class="fa fa-pencil color-w icon-middle"></i>
	</div>
	<div class="_5e4">
		<form id="editcategory-form" enctype="multipart/form-data" method="POST">
			<div class="vByg5">
				<input type="text" name="ec_name" value="{{EDIT_CATEGORY_NAME}}">
				<input type="hidden" name="ec_id" value="{{EDIT_CATEGORY_ID}}">
			</div>
			<button type="submit" class="btn-p btn-p1">
				<i class="fa fa-check icon-middle"></i>
				@save@
			</button>
		</form>
	</div>
</div>