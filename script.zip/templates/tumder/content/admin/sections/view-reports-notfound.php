<div class="_a-c _e55">
	<div>
		<img src="{{CONFIG_THEME_PATH}}/image/icon-color/megaphone.png">
	</div>
	<h3>@no_reports@</h3>
</div>