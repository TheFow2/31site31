<div class="tumd-main-headself">
	<i class="fa fa-gamepad"></i>
</div>
<div class="general-box">
	<button id="publish-all-games" class="btn-p btn-p4"><i class="fa fa-globe"></i> @publish_all_games@</button>
	<button id="install-premium-games-catalog" class="btn-p btn-premium"><i class="fa fa-star"></i> @admin_install_premium_games@</button>
	<button id="install-games-catalog" class="btn-p btn-p2"><i class="fa fa-download"></i> @admin_action_get_catalog@</button>

	<div class="installing-message"></div>
</div>
{{GAMES_CONTAINER}}