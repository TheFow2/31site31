<ul class="_rep-container">
	{{REPORTS_LIST}}
</ul>