<li class="report-r{{REPORT_DATA_ID}} _rep-item">
	<div class="g-d5 _j4">
		<button class="report-btn-action ot fa fa-thumbs-up icon-18 ic-act ic-2" data-rp-action="1" data-rp-id="{{REPORT_DATA_ID}}" data-user="{{REPORT_DATA_USER_ID}}"></button>
		<button class="report-btn-action ot fa fa-thumbs-down icon-18 ic-act ic-3" data-rp-action="2" data-rp-id="{{REPORT_DATA_ID}}"></button>
		<button class="ot fa fa-pencil icon-18 ic-act ic-1" data-href="{{CONFIG_SITE_URL}}/admin/games/edit/{{REPORT_DATA_ID_REPORTED}}"></button>
	</div>
	<div>{{REPORT_DATA_USER}}</div>
	<textarea class="b-input scroll-custom" readonly="readonly">{{REPORT_DATA_INFO}}</textarea>
</li>