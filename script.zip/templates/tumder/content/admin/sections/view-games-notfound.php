<div class="_a-c _e55">
	<div>
		<img src="{{CONFIG_THEME_PATH}}/image/icon-color/controller.png">
	</div>
	<h3>@no_games@</h3>
</div>