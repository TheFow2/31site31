<div class="general-box _0e4">
	<div class="header-box">
		<i class="fa fa-plus color-w icon-middle"></i>
	</div>
	<div class="_5e4">
		<form id="addcategory-form" enctype="multipart/form-data" method="POST" autocomplete="off">
			<div class="vByg5">
				<input type="text" name="ac_name" placeholder="@category_name@">
			</div>
			<button type="submit" class="btn-p btn-p1">
				<i class="fa fa-plus icon-middle"></i>
				@add@
			</button>
		</form>
	</div>
</div>