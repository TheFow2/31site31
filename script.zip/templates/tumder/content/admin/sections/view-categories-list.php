<li class="__mc-{{VIEW_CATEGORY_ID}} g-d5 _j4 categories-item">
	<div class="_category-name">{{VIEW_CATEGORY_NAME}}</div>
	<div>
		<button data-href="{{CONFIG_SITE_URL}}/admin/categories/edit/{{VIEW_CATEGORY_ID}}" class="btn-p btn-small btn-p2 fa fa-pencil"></button>
		{{VIEW_CATEGORY_BUTTON_DELETE}}
	</div>
</li>