<div class="tumd-main-headself">
	<i class="fa fa-flag-o"></i>
</div>
<div class="general-box _yt10 _yb10 _0e4">
	<form id="adsArea-form" method="POST">
		<div class="g-d5">
			<div class="r05-t _b-r _5e4">
				<span class="_f12">@ads_header@</span>
				<textarea class="b-input scroll-custom" name="ad_header">{{ADS_AREA_HEADER}}</textarea>

				<span class="_f12">@ads_footer@</span>
				<textarea class="b-input scroll-custom" name="ad_footer">{{ADS_AREA_FOOTER}}</textarea>

				<span class="_f12">@ads_home_sidebar@</span>
				<textarea class="b-input scroll-custom" name="ad_column_one">{{ADS_AREA_COLUMN_ONE}}</textarea>
			</div>
			<div class="r05-t _5e4">
				<span class="_f12">@ads_game_section_top@</span>
				<textarea class="b-input scroll-custom" name="ad_gameTop">{{ADS_AREA_GAMETOP}}</textarea>

				<span class="_f12">@ads_game_section_bottom@</span>
				<textarea class="b-input scroll-custom" name="ad_gameBottom">{{ADS_AREA_GAMEBOTTOM}}</textarea>

				<span class="_f12">@ads_game_section_info@</span>
				<textarea class="b-input scroll-custom" name="ad_gameInfo">{{ADS_AREA_GAMEINFO}}</textarea>
			</div>
		</div>
		<div class="_a-r _5e4 _b-t">
			<button type="submit" class="btn-p btn-p1">
				<i class="fa fa-check icon-middle"></i>
				@save@
			</button>
		</div>
	</form>
</div>