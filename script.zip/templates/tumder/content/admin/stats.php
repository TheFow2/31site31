<div class="_header-section admin-hh-style">
	<span class="_content-title _content-color-a"><img class="img-50" src="{{CONFIG_THEME_PATH}}/image/icon-color/shield.png"> @administration@</span>
</div>
<div class="general-box stats-box-container _yt10 _yb10">
	<div class="stats-box" title="@games_installed@">
		<div class="stats-icon-box stats-bg-one"><i class="fa fa-gamepad"></i></div>
		<div class="stats-info stats-color-one ellipsis">{{ADMIN_STATS_GAMES}}</div>	
	</div>
	<div class="stats-box" title="@users_registered@">
		<div class="stats-icon-box stats-bg-two"><i class="fa fa-user"></i></div>
		<div class="stats-info stats-color-two ellipsis">{{ADMIN_STATS_USERS}}</div>	
	</div>
	<div class="stats-box" title="@categories_registered@">
		<div class="stats-icon-box stats-bg-three"><i class="fa fa-bookmark"></i></div>
		<div class="stats-info stats-color-three ellipsis">{{ADMIN_STATS_CATEGORIES}}</div>	
	</div>
</div>

<div class="g-d5 general-box _0e4 _yt10 _yb10 r-r3 users-status-dashboard">
	<div class="r05-t _b-r _a-j last-users-container">
		<div class="_5e4 _tr5 box-header"><i class="fa fa-user-plus icon-18 icon-middle"></i> @last_users_registered@</div>
		{{STATS_LAST_USER_REGISTERED_LIST}}
	</div>

	<div class="r05-t _a-j last-users-container">
		<div class="_5e4 _tr5 box-header"><i class="fa fa-sign-in icon-18 icon-middle"></i> @last_users_logged@</div>
		{{STATS_LAST_USER_LOGGED_LIST}}
	</div>
</div>