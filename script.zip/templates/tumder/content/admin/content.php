<div class="page-wrapper">
	<div class="tumd-main pull-right span79">
		{{PAGE_ADMIN_CONTENT}}
	</div>

	<div class="tumd-nav pull-left span20">
		<div class="tumd-nav-headself">
			@administration@
		</div>
		{{ADMIN_NAVIGATION_MENU}}
	</div>
</div>