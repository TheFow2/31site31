<ul>
	<li class="_4lf {{NAV_MENU_INFO}}">
		<a href="{{CONFIG_SITE_URL}}/setting" class="_p spf-link"></a> 
		<i class="fa fa-cogs nav-icon icon-middle"></i> @general@
	</li>
	<li class="_4lf {{NAV_MENU_AVATAR}}">
		<a href="{{CONFIG_SITE_URL}}/setting/avatar" class="_p spf-link"></a> 
		<i class="fa fa-user-circle nav-icon icon-middle"></i> @avatar@
	</li>
	<li class="_4lf {{NAV_MENU_THEME}}">
		<a href="{{CONFIG_SITE_URL}}/setting/theme" class="_p spf-link"></a> 
		<i class="fa fa-tint nav-icon icon-middle"></i> @theme@
	</li>
	<li class="_4lf {{NAV_MENU_PASSWORD}}">
		<a href="{{CONFIG_SITE_URL}}/setting/password" class="_p spf-link"></a> 
		<i class="fa fa-key nav-icon icon-middle"></i> @change_password@
	</li>
</ul>