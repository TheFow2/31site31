<div class="page-wrapper">
<div class="tumd-main pull-right span79">
	<div class="tumd-main-headself">
		<i class="fa fa-navicon"></i>
	</div>
	<div class="tumd-main-content">
        {{SETTING_PAGE_CONTENT}}
	</div>
</div>

<div class="tumd-nav pull-left span20">
    <div class="tumd-nav-headself">@configuration@</div>
    {{SETTING_NAVIGATION_MENU}}
</div>
</div>