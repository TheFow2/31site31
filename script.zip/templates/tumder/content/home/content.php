{{ADS_HEADER}}
<div class="page-wrapper">
	<div class="tumd-main main-box pull-left span69">
		<div class="tumd-section-s landing-pattern">
			<div class="_content-title _a-l">
				<img class="img-20" src="{{CONFIG_THEME_PATH}}/image/icon-color/new.png"> @new_games@
			</div>
			{{NEW_GAMES}}
		</div>
		<div class="tumd-game-featured _a-c">
			<span class="_content-title _content-color-a _a-l"><img class="img-20" src="{{CONFIG_THEME_PATH}}/image/icon-color/heart.png"> @featured_games@</span>
			{{FEATURED_GAMES}} 
		</div>
		<div class="tumd-main-content games-m-played">
			<span class="_content-title"><img class="img-20" src="{{CONFIG_THEME_PATH}}/image/icon-color/crown.png"> @most_played@</span>
			{{MOSTPLAYED_GAMES}}
		</div>
	</div>
	{{MAIN_SIDEBAR}}
</div>
{{ADS_FOOTER}}