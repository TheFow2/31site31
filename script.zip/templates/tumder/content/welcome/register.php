<div class="tumd-door">
	<div class="door-circle-itr">
		<img src="{{CONFIG_THEME_PATH}}/image/icon-color/sign_up.png">
	</div>
	<div class="tumd-door-container">
		<form class="signup-form" method="post">
			<div class="form-header">@sign_up@</div>
			<div class="vByg5">
				<input type="email" name="email" placeholder="@email@">
			</div>
			<div class="vByg5">
				<input type="text" name="name" placeholder="@name@">
			</div>
			<div class="vByg5">
				<input type="text" name="username" placeholder="@user@">
			</div>
			<div class="vByg5">
				<input type="password" name="password" placeholder="@password@">
			</div>

			<div class="_yt10 _a-r">
				<input class="submit-btn btn-p btn-p2" type="submit" value="@sign_up@">
			</div>
		</form>
	</div>
</div>