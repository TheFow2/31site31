<div class="_a-c _e55">
	<div>
		<img src="{{CONFIG_THEME_PATH}}/image/icon-color/404.png">
	</div>
	<h3>@error_404@</h3>
</div>