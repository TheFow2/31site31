<div class="tumd-main span100">
	<div class="_header-section">
		<span class="_content-title _content-color-a"><img class="img-50" src="{{CONFIG_THEME_PATH}}/image/icon-color/globe.png"> @community@</span>
	</div>
	<div class="general-box _yt10 _yb10">
		<span class="_content-title"><img class="img-20" src="{{CONFIG_THEME_PATH}}/image/icon-color/leaderboard.png"> @top_xp@</span>

		<ul class="community-leaderboard">
			{{TOP_XP_LIST}}
		</ul>
	</div>
</div>