<li>
	<span class="community-position">
		{{USER_TOP_POSITION}}
	</span>
	<a data-href="{{CONFIG_SITE_URL}}/profile/{{USERNAME}}">
		<img class="community-avatar {{TOP_XP_CLASS}}" src="{{AVATAR}}">
		<div class="community-name ellipsis">{{USERNAME}}</div>
	</a>
	<div class="community-xp ellipsis" title="{{USER_XP}} @xp@">
		{{USER_STR_XP}} @xp@
	</div>
	{{ADMIN_USER_CONTROL}}
</li>