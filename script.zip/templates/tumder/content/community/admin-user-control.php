<button class="admin-user-btn" data-href="{{CONFIG_SITE_URL}}/admin/users/edit/{{USERNAME}}">
	<i class="fa fa-wrench"></i>
</button>