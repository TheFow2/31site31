<div id="carousel-random-games" class="owl-carousel owl-theme">
	{{CAROUSEL_RANDOM_LIST}}
</div>
<script type="text/javascript">
	$(document).ready(function() {
		$("#carousel-random-games").owlCarousel({
			items: {{CAROUSEL_RANDOM_GAMES_ITEMS}},
			autoPlay: true
		});
	});
</script>