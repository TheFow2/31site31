<div class="tumd-header">
	<div class="tumd-header-nav">
		<div class="_h-c">
			<div class="tumd-logo">
				<a class="spf-link" href="{{CONFIG_SITE_URL}}/">
					<img src="{{CONFIG_SITE_URL}}/static/logo/td-white-logo.png" width="160" logo>
					<img src="{{CONFIG_SITE_URL}}/static/logo/td-logo-responsive.png" width="35" logo-responsive>
				</a>
			</div>
			<div class="tumd-search">
				<form id="search-data-form" method="POST" autocomplete="off">
					<input class="search-input" id="Search-InArea" name="search_parameter" placeholder="@search_games@" type="text">
				</form>
			</div>
			<div class="nav-menu {{HEADER_CLASS_ACCESS_MENU}}">
				<div id="nav-icon">
  					<span></span>
					<span></span>
					<span></span>
					<span></span>
				</div>
			</div>
			<div class="header-nav {{HEADER_CLASS_ACCESS_MENU}}">
				<ul>
					<li><a class="spf-link" href="{{CONFIG_SITE_URL}}/community" title="@community@">
						<i class="fa fa-globe icon-22 icon-middle"></i>
						<span>@community@</span>
					</a></li>
					<li><a class="spf-link" href="{{CONFIG_SITE_URL}}/categories" title="@categories@">
						<i class="fa fa-th-large icon-22 icon-middle"></i>
						<span>@categories@</span>
					</a></li>
					{{HEADER_MENU_OFFLINE}}
				</ul>
			</div>
			<script type="text/javascript">
				$('#nav-icon').click(function() { 
    				$('.header-nav').toggleClass('show-menu');
    				$(this).toggleClass('open');
  				});
			</script>
			{{HEADER_PANEL_DROPDOWN}}
			</div>
		</div>
		<div class="tumd-page-loadbar"></div>
	</div>
</div>