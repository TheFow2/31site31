	<li><a class="spf-link" button1 href="{{CONFIG_SITE_URL}}/login">
		@sign_in@
	</a></li>
	<li><a class="spf-link" button2 href="{{CONFIG_SITE_URL}}/signup">
		@sign_up@
	</a></li>