<div class="small">
	<div class="_a-c"><i class="fa fa-gamepad"></i></div>
	<div>@no_games_found@</div>
</div>