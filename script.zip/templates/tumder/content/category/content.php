<div class="tumd-main span100">
	{{CATEGORY_CONTENT}}
</div>