<div class="category-section-top">
	<span data-href="{{CONFIG_SITE_URL}}/categories"><i class="fa fa-tags"></i> @categories@ <i class="fa fa-chevron-right"></i></span> {{CATEGORY_NAME}}
</div>
<ul class="card">
	{{CATEGORY_GAMES_LIST}}
</ul>