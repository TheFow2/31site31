<div class="_header-section">
	<span class="_content-title _content-color-a">
		<img class="img-50" src="{{CONFIG_THEME_PATH}}/image/icon-color/joker.png"> 
		@categories@
	</span>
</div>
<ul>
	{{CATEGORIES_LIST}}
</ul>