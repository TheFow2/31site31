<li class="card-item">
	<figure class="card-game">
		<a class="g-media" data-href="{{CATEGORY_GAME_URL}}" href="{{CATEGORY_GAME_URL}}">
			<img src="{{CATEGORY_GAME_IMAGE}}" width="140px" height="96px">
			<span class="name ellipsis">{{CATEGORY_GAME_NAME}}</span>
			<div class="meter mtr-2" value="{{CATEGORY_GAME_RATING}}" title="{{CATEGORY_GAME_RATING}} @of_5_stars@"></div>
		</a>
		<span class="cb-pro"></span>
	</figure>
</li>