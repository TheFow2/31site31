<li class="category-list-item">
	<div class="category-icon">
		<i class="fa fa-chevron-right"></i>
	</div>
	<div class="ellipsis">
		{{CATEGORY_NAME}}
	</div>
	<a class="_p" href="{{CATEGORY_URL}}"></a>
</li>