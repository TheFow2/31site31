<div class="tumd-main span100">
	<div class="tumd-profile">
		<div class="user-profile-cover {{PROFILE_THEME}}">
			<div class="user-profile-wrapper">
				<div class="_profile-image">
					<img src="{{PROFILE_AVATAR}}" class="_profile-picture">
				</div>
				<div class="_profile-name">
					<span>{{PROFILE_NAME}}</span>
				</div>
			</div>
		</div>
		<div class="page-wrapper _yt10">
			<div class="container-widget pull-left span30">
				<aside>
					<div class="widget">
						<div class="widget-header"><i class="fa fa-info-circle"></i> @profile_information@</div>
						<div class="_5e4 _b-b">
							{{PROFILE_GENDER}}
						</div>
						<div class="_5e4">
							<img class="img-20" src="{{CONFIG_THEME_PATH}}/image/icon-color/pencil.png">
							{{PROFILE_ABOUT}}
						</div>
					</div>
				</aside>
				{{ADS_SIDEBAR}}
			</div>
			<div class="tumd-main main-box pull-right span69">
				<div>
					<span class="_content-title"><img class="img-20" src="{{CONFIG_THEME_PATH}}/image/icon-color/plays.png"> @new_games_visited@</span>
					<div id="lastgames-played-carousel" class="owl-carousel owl-theme">
						{{PROFILE_GAME_PLAYED_LIST}}
					</div>
					<script type="text/javascript">
						$(document).ready(function() {
							$("#lastgames-played-carousel").owlCarousel({
								items: 2,
								autoPlay: true
							});
						});
					</script>
				</div>
				<div>
					<span class="_content-title"><img class="img-20" src="{{CONFIG_THEME_PATH}}/image/icon-color/star.png"> @my_favorite_games@</span>
					<ul class="card">
						{{PROFILE_GAME_FAVORITE_LIST}}
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>