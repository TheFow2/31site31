<div class="_a-c g-top-group share-section">
	<!-- Facebook -->
	<a class="share-btn facebook" id="share-btn" data-share-url="https://www.facebook.com/share.php?u={{PLAY_GAME_URL}}">Facebook</a>
	
	<!-- Twitter -->
	<a class="share-btn twitter" id="share-btn" data-share-url="https://twitter.com/intent/tweet?text={{PLAY_GAME_NAME}} - {{CONFIG_SITE_NAME}}&url={{PLAY_GAME_URL}}&original_referer={{PLAY_GAME_URL}}">Twitter</a>
	
	<!-- Google+ -->
	<a class="share-btn google" id="share-btn" data-share-url="https://plus.google.com/share?url={{PLAY_GAME_URL}}">Google+</a>
</div>