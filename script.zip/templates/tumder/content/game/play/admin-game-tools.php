<div class="_a-c g-top-group b-dsh-bottom">
	<canvas id="admintool_chart_game_analytics"></canvas>
</div>