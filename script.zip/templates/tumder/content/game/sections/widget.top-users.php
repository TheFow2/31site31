<aside>
	<div class="widget">
		<div class="widget-header">
			<i class="fa fa-star-half-o"></i>
			@top_users_xp@
		</div>
	    <ul class="widget-list">
			{{WIDGET_SIDEBAR_TOP_USERS_LIST}}
		</ul>
	</div>
</aside>