<aside>
	<div class="widget">
		<div class="widget-header">
			<i class="fa fa-star"></i>
			@top_stars@
		</div>
	    <ul class="widget-list">
			{{WIDGET_SIDEBAR_TOP_STAR_LIST}}
		</ul>
	</div>
</aside>