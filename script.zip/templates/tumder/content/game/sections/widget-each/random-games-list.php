<li class="item">
	<a class="item-thumbnail pull-left" href="{{RANDOM_GAME_URL}}">
		<img src="{{RANDOM_GAME_IMAGE}}" width="60px" height="41px">
	</a>
	<div class="body pull-left">
		<div class="title ellipsis">
			<a href="{{RANDOM_GAME_URL}}" title="@play_to@ {{RANDOM_GAME_NAME}}">{{RANDOM_GAME_NAME}}</a>
		</div>
		<div class="meter mtr-2" value="{{RANDOM_GAME_RATING}}"></div>
	</div>
</li>