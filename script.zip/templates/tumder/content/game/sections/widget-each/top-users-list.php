<li class="item">
	<a class="item-thumbnail pull-left" href="{{PROFILE_URL}}">
		<img src="{{AVATAR}}" width="60px" height="60px">
	</a>
	<div class="body pull-left">
		<div class="title ellipsis">
			<a href="{{PROFILE_URL}}">{{NAME}}</a>
		</div>
		<div>
			{{TOP_XP_MEDAL}}
		</div>
	</div>
</li>