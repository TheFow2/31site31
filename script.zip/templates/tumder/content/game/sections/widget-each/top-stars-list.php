<li class="item">
	<a class="item-thumbnail pull-left" href="{{WIDGET_TOPSTAR_URL}}">
		<img src="{{WIDGET_TOPSTAR_IMAGE}}" width="60px" height="41px">
	</a>
	<div class="body pull-left">
		<div class="title ellipsis">
			<a href="{{WIDGET_TOPSTAR_URL}}" title="@play_to@ {{WIDGET_TOPSTAR_NAME}}">{{WIDGET_TOPSTAR_NAME}}</a>
		</div>
		<div class="meter mtr-2" value="{{WIDGET_TOPSTAR_RATING}}"></div>
	</div>
</li>