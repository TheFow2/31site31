<li class="item">
	<div class="small _a-c">@no_games_found@</div>
</li>