<aside>
	<div class="widget">
		<div class="widget-header">
			<i class="fa fa-cube"></i>
			@random_games@
		</div>
	    <ul class="widget-list">
			{{WIDGET_SIDEBAR_RANDOM_LIST}}
		</ul>
	</div>
</aside>