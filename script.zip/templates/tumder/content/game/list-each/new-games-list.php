<div class="item-c-media" data-href="{{NEW_GAME_URL}}">
	<span class="game-c-media">
		<img src="{{NEW_GAME_IMAGE}}">
	</span>
	<h1 class="c-title ellipsis">{{NEW_GAME_NAME}}</h1>
	<div class="c-info">
		<div class="c-subtitle">
			<div class="meter mtr-2" value="{{NEW_GAME_RATING}}" title="{{NEW_GAME_RATING}} @of_5_stars@"></div>
		</div>
	</div>
	<img class="game-b-media-img" src="{{NEW_GAME_IMAGE}}">
</div>