<div class="container-widget pull-right span30">
	{{ADS_SIDEBAR}}

	{{MAIN_SIDEBAR_WIDGETS}}

	<div style="margin-top:10px;font-size:12px">
		Powered by <a href="https://tumderstorm.com" style="color:#6f7380">Tumder Arcade Script</a>
	</div>
</div>