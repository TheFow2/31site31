<div id="newgames-carousel" class="owl-carousel owl-theme">
	{{NEW_GAMES_LIST}}
</div>
<script type="text/javascript">
	$(document).ready(function() {
		$("#newgames-carousel").owlCarousel({
			items: 2,
			autoPlay: true
		});
	});
</script>