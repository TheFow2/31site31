<div class="_Ad-game">
	<div class="_a-r">
		<button class="_removeAd" disabled>
			<span class="__r-Ad-1">
				<span class="rAdNum">0</span>
				@seconds_to_remove_ads@
			</span>
			<span class="__r-Ad-2 _a0">
				<i class="fa fa-close"></i>
				@remove_ads@
			</span>
		</button>
	</div>
	{{PLAY_GAME_ADS_GAMETOP}}
	<div class="AdCountDown">
		<img src="{{CONFIG_SITE_URL}}/static/libs/images/ajax-spinner.svg" width="100%" height="100%">
		<span class="Adnum">0</span>
	</div>
	{{PLAY_GAME_ADS_GAMEBOTTOM}}
</div>