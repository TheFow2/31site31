<section>
	<div class="game-container">
		<div class="game-content">
			<div class="game-case">
				<div class="iframe-wrapper">
					{{PLAY_GAME_ADS_COUNTER}}
					<div class="gmDisplay" style="{{PLAY_GAME_DISPLAY}}">
						{{PLAY_GAME_EMBED}}
					</div>
				</div>
			</div>
		</div>
	</div>
	<section class="game-info">
		<div class="game-connect-box">
			<div class="game-content">
				<header class="main-info">
					<div class="info-self">
						<span class="game-thumbnail pull-left">
							<img src="{{PLAY_GAME_IMAGE}}" width="60" height="41">
						</span>
						<hgroup class="pull-left">
							<h1 class="ellipsis">{{PLAY_GAME_NAME}}</h1>
							<div class="meter mtr-2" value="{{PLAY_GAME_RATING}}" title="{{PLAY_GAME_RATING}} @of_5_stars@"></div>
						</hgroup>
					</div>
					<ul class="set-btn h-list pull-right">
						<li>
							{{PLAY_GAME_FAVORITE_BTN}}
						</li>
						<li>
							<button class="top-gm-btn fs-action-button initFullScreen fa fa-arrows-alt" data-fullscreen-item=".iframe-wrapper"></button>
						</li>
						<li>
							<button class="top-gm-btn rpt-action-button fa fa-exclamation-circle" id="report-btn" data-report="{{PLAY_GAME_ID}}"></button>
						</li>
						<li>
							{{PLAY_GAME_ADMIN_BTN}}
						</li>
					</ul>
				</header>
			</div>
		</div>
	</section>
</section>
<div class="page-wrapper tumd-container">
	<div class="pull-left span69">
		<div class="tumd-main main-box">

			{{PLAYGAME_MAIN_CONTENT}}
			
			<div class="g-top-group o-hidden b-dsh-top">
				<div class="game-txt-info pull-left">
					<img src="{{CONFIG_THEME_PATH}}/image/icon-color/calendar.png" class="img-30">
					{{PLAY_GAME_DATE}}
				</div>
				<div class="game-txt-info pull-right">
					<img src="{{CONFIG_THEME_PATH}}/image/icon-color/controller.png" class="img-30">
					{{PLAY_GAME_PLAYS}}
				</div>
			</div>
			<div class="game-txt-info g-group _a-c b-dsh-top">
				<p>
					<strong>@description@</strong>
				</p>
				<span>{{PLAY_GAME_DESC}}</span>
			</div>
			<div class="game-txt-info g-group _a-c b-dsh-top">
				<p>
					<strong>@instructions@</strong>
				</p>
				<span>{{PLAY_GAME_INST}}</span>
			</div>
		</div>
		{{PLAY_WIDGET_CAROUSEL_RANDOM_GAMES}}
	</div>
	<div class="container-widget pull-right span30">
		<aside>
			{{PLAY_SIDEBAR_WIDGETS}}
		</aside>
	</div>
</div>
{{PLAY_GAME_ADS_GAMEINFO}}