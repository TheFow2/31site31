<?php if ( ! defined('API_PILOT') ) exit(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta name="robots" content="noindex, nofollow">
	<style type="text/css">
		* {margin: 0;padding: 0;}
		#api_game_embed {position: absolute!important;width: 100%;height: 100%;}
	</style>
</head>
<body>
	<?php include( $get_game_type_container );?>
</body>
</html>